﻿using System;
using System.Runtime.InteropServices;

namespace MIDI
{
    class Program
    {
        static void Main(string[] args)
        {
            #region 新的
            MIDIHelper helper = new MIDIHelper();
            Console.WriteLine(msg); ;
            helper.Open();
            MusicNo musicNo = 0;
            select:
            Console.WriteLine("选择乐器，输入编号（0-127)");
            try
            {
                musicNo = (MusicNo)int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("没有这件乐器");
                goto select;
            }
            uint tone = 60;
            uint volume = 120;
            uint channel = 0;
            helper.ChangeInstruments(musicNo);
            uint toneInput = 0;

            Console.WriteLine("按其他键，可以停止发音");
            Console.WriteLine("按Enter键，可以从新选择乐器");
            Console.WriteLine("ESC键退出程序");

            Console.WriteLine("现在可以开始弹奏了，请保持英文输入法");
            Console.WriteLine(@"
Q:高do   W:高re   E:高mi   R:高fa   T:高so   Y:高la   U:高xi
A:中do   S:中re   D:中mi   F:中fa   G:中so   H:中la   J:中xi
Z:低do   X:低re   C:低mi   V:低fa   B:低so   N:低la   M:低xi
");
            while (true)
            {
                var input = Console.ReadKey(true);
                helper.Stop(toneInput,channel);
                if (input.Key == ConsoleKey.Escape)
                {
                    break;
                }
                if (input.Key == ConsoleKey.Enter)
                {
                    goto select;
                }
                if (input.Key == ConsoleKey.Z)
                {
                    toneInput = tone - 7 * 2 + 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.X)
                {

                    toneInput = tone - 6 * 2 + 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.C)
                {

                    toneInput = tone - 5 * 2 + 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.V)
                {

                    toneInput = tone - 4 * 2 + 1;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.B)
                {
                    toneInput = tone - 3 * 2 + 1;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.N)
                {
                    toneInput = tone - 2 * 2 + 1;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.M)
                {
                    toneInput = tone - 1 * 2 + 1;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.A)
                {
                    toneInput = tone + 0 * 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.S)
                {
                    toneInput = tone + 1 * 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.D)
                {
                    toneInput = tone + 2 * 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.F)
                {
                    toneInput = tone + 3 * 2 - 1;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.G)
                {
                    toneInput = tone + 4 * 2 - 1;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.H)
                {
                    toneInput = tone + 5 * 2 - 1;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.J)
                {
                    toneInput = tone + 6 * 2 - 1;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.Q)
                {
                    toneInput = tone + 7 * 2 - 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.W)
                {
                    toneInput = tone + 8 * 2 - 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.E)
                {
                    toneInput = tone + 9 * 2 - 2;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.R)
                {
                    toneInput = tone + 10 * 2 - 3;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.T)
                {
                    toneInput = tone + 11 * 2 - 3;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.Y)
                {
                    toneInput = tone + 12 * 2 - 3;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
                if (input.Key == ConsoleKey.U)
                {
                    toneInput = tone + 13 * 2 - 3;
                    helper.Play(toneInput, volume, channel);
                    continue;
                }
            }
            helper.Close();
            #endregion
            #region 原来的


            //Midi midi = new Midi();
            ////y乐器
            //uint id = (uint)MusicNo.Piccolo;
            ////音调
            //uint tone = 65;
            ////音量
            //uint volume = 100;
            ////通道
            //uint channel = 8;
            //midi.OpenMidiDevi();
            //midi.ChangeVirtualMusicalInstruments(id);
            //while (true)
            //{
            //    var input = Console.ReadKey(true);
            //    uint toneInput = 0;
            //    if (input.Key == ConsoleKey.Escape)
            //    {
            //        break;
            //    }
            //    if (input.Key == ConsoleKey.Z)
            //    {

            //        toneInput = tone - 7 * 2 + 2;
            //    }
            //    if (input.Key == ConsoleKey.X)
            //    {

            //        toneInput = tone - 6 * 2 + 2;
            //    }
            //    if (input.Key == ConsoleKey.C)
            //    {

            //        toneInput = tone - 5 * 2 + 2;
            //    }
            //    if (input.Key == ConsoleKey.V)
            //    {

            //        toneInput = tone - 4 * 2 + 2;
            //    }
            //    if (input.Key == ConsoleKey.B)
            //    {
            //        toneInput = tone - 3 * 2 + 1;
            //    }
            //    if (input.Key == ConsoleKey.N)
            //    {
            //        toneInput = tone - 2 * 2 + 1;
            //    }
            //    if (input.Key == ConsoleKey.M)
            //    {
            //        toneInput = tone - 1 * 1;
            //    }
            //    if (input.Key == ConsoleKey.A)
            //    {
            //        toneInput = tone + 0 * 2;
            //    }
            //    if (input.Key == ConsoleKey.S)
            //    {
            //        toneInput = tone + 1 * 2;
            //    }
            //    if (input.Key == ConsoleKey.D)
            //    {
            //        toneInput = tone + 2 * 2;
            //    }
            //    if (input.Key == ConsoleKey.F)
            //    {
            //        toneInput = tone + 3 * 2;
            //    }
            //    if (input.Key == ConsoleKey.G)
            //    {
            //        toneInput = tone + 4 * 2 - 1;
            //    }
            //    if (input.Key == ConsoleKey.H)
            //    {
            //        toneInput = tone + 5 * 2 - 1;
            //    }
            //    if (input.Key == ConsoleKey.J)
            //    {
            //        toneInput = tone + 6 * 2 - 1;
            //    }
            //    if (input.Key == ConsoleKey.Q)
            //    {
            //        toneInput = tone + 7 * 2 - 2;
            //    }
            //    if (input.Key == ConsoleKey.W)
            //    {
            //        toneInput = tone + 8 * 2 - 2;
            //    }
            //    if (input.Key == ConsoleKey.E)
            //    {
            //        toneInput = tone + 9 * 2 - 2;
            //    }
            //    if (input.Key == ConsoleKey.R)
            //    {
            //        toneInput = tone + 10 * 2 - 2;
            //    }
            //    if (input.Key == ConsoleKey.T)
            //    {
            //        toneInput = tone + 11 * 2 - 3;
            //    }
            //    if (input.Key == ConsoleKey.Y)
            //    {
            //        toneInput = tone + 12 * 2 - 3;
            //    }
            //    if (input.Key == ConsoleKey.U)
            //    {
            //        toneInput = tone + 13 * 2 - 3;
            //    }
            //    if (toneInput != 0)
            //    {
            //        midi.ShortPlay(toneInput, volume, channel);
            //    }
            //}
            //midi.CloseMidiDevi();
            //Console.WriteLine("退出演奏");


            #endregion
        }
        #region 乐器列表
        static string msg = @"
0 Acoustic Grand Piano 大钢琴（声学钢琴）
1 Bright Acoustic Piano 明亮的钢琴
2 Electric Grand Piano 电钢琴
3 Honky-tonk Piano 酒吧钢琴
4 Rhodes Piano 柔和的电钢琴
5 Chorused Piano 加合唱效果的电钢琴
6 Harpsichord 羽管键琴（拨弦古钢琴）
7 Clavichord 科拉维科特琴（击弦古钢琴）

色彩打击乐器
8 Celesta 钢片琴
9 Glockenspiel 钟琴
10 Music box 八音盒
11 Vibraphone 颤音琴
12 Marimba 马林巴
13 Xylophone 木琴
14 Tubular Bells 管钟
15 Dulcimer 大扬琴

风琴
16 Hammond Organ 击杆风琴
17 Percussive Organ 打击式风琴
18 Rock Organ 摇滚风琴
19 Church Organ 教堂风琴
20 Reed Organ 簧管风琴
21 Accordian 手风琴
22 Harmonica 口琴
23 Tango Accordian 探戈手风琴

吉他
24 Acoustic Guitar (nylon) 尼龙弦吉他
25 Acoustic Guitar (steel) 钢弦吉他
26 Electric Guitar (jazz) 爵士电吉他
27 Electric Guitar (clean) 清音电吉他
28 Electric Guitar (muted) 闷音电吉他
29 Overdriven Guitar 加驱动效果的电吉他
30 Distortion Guitar 加失真效果的电吉他
31 Guitar Harmonics 吉他和音

贝司
32 Acoustic Bass 大贝司（声学贝司）
33 Electric Bass(finger) 电贝司（指弹）
34 Electric Bass (pick) 电贝司（拨片）
35 Fretless Bass 无品贝司
36 Slap Bass 1 掌击Bass 1
37 Slap Bass 2 掌击Bass 2
38 Synth Bass 1 电子合成Bass 1
39 Synth Bass 2 电子合成Bass 2

弦乐
40 Violin 小提琴
41 Viola 中提琴
42 Cello 大提琴
43 Contrabass 低音大提琴
44 Tremolo Strings 弦乐群颤音音色
45 Pizzicato Strings 弦乐群拨弦音色
46 Orchestral Harp 竖琴
47 Timpani 定音鼓

合奏/合唱
48 String Ensemble 1 弦乐合奏音色1
49 String Ensemble 2 弦乐合奏音色2
50 Synth Strings 1 合成弦乐合奏音色1
51 Synth Strings 2 合成弦乐合奏音色2
52 Choir Aahs 人声合唱“啊”
53 Voice Oohs 人声“嘟”
54 Synth Voice 合成人声
55 Orchestra Hit 管弦乐敲击齐奏

铜管
56 Trumpet 小号
57 Trombone 长号
58 Tuba 大号
59 Muted Trumpet 加弱音器小号
60 French Horn 法国号（圆号）
61 Brass Section 铜管组（铜管乐器合奏音色）
62 Synth Brass 1 合成铜管音色1
63 Synth Brass 2 合成铜管音色2
簧管
64 Soprano Sax 高音萨克斯风
65 Alto Sax 次中音萨克斯风
66 Tenor Sax 中音萨克斯风
67 Baritone Sax 低音萨克斯风
68 Oboe 双簧管
69 English Horn 英国管
70 Bassoon 巴松（大管）
71 Clarinet 单簧管（黑管）

笛
72 Piccolo 短笛
73 Flute 长笛
74 Recorder 竖笛
75 Pan Flute 排箫
76 Bottle Blow [中文名称暂缺]
77 Shakuhachi 日本尺八
78 Whistle 口哨声
79 Ocarina 奥卡雷那

合成主音
80 Lead 1 (square) 合成主音1（方波）
81 Lead 2 (sawtooth) 合成主音2（锯齿波）
82 Lead 3 (caliope lead) 合成主音3
83 Lead 4 (chiff lead) 合成主音4
84 Lead 5 (charang) 合成主音5
85 Lead 6 (voice) 合成主音6（人声）
86 Lead 7 (fifths) 合成主音7（平行五度）
87 Lead 8 (bass+lead)合成主音8（贝司加主音）

合成音色
88 Pad 1 (new age) 合成音色1（新世纪）
89 Pad 2 (warm) 合成音色2 （温暖）
90 Pad 3 (polysynth) 合成音色3
91 Pad 4 (choir) 合成音色4 （合唱）
92 Pad 5 (bowed) 合成音色5
93 Pad 6 (metallic) 合成音色6 （金属声）
94 Pad 7 (halo) 合成音色7 （光环）
95 Pad 8 (sweep) 合成音色8

合成效果
96 FX 1 (rain) 合成效果 1 雨声
97 FX 2 (soundtrack) 合成效果 2 音轨
98 FX 3 (crystal) 合成效果 3 水晶
99 FX 4 (atmosphere) 合成效果 4 大气
100 FX 5 (brightness) 合成效果 5 明亮
101 FX 6 (goblins) 合成效果 6 鬼怪
102 FX 7 (echoes) 合成效果 7 回声
103 FX 8 (sci-fi) 合成效果 8 科幻

民间乐器
104 Sitar 西塔尔（印度）
105 Banjo 班卓琴（美洲）
106 Shamisen 三昧线（日本）
107 Koto 十三弦筝（日本）
108 Kalimba 卡林巴
109 Bagpipe 风笛
110 Fiddle 民族提琴
111 Shanai 山奈

打击乐器
112 Tinkle Bell 叮当铃
113 Agogo [中文名称暂缺]
114 Steel Drums 钢鼓
115 Woodblock 木鱼
116 Taiko Drum 太鼓
117 Melodic Tom 通通鼓
118 Synth Drum 合成鼓
119 Reverse Cymbal 铜钹

Sound Effects 声音效果
120 Guitar Fret Noise 吉他换把杂音
121 Breath Noise 呼吸声
122 Seashore 海浪声
123 Bird Tweet 鸟鸣
124 Telephone Ring 电话铃
125 Helicopter 直升机
126 Applause 鼓掌声
127 Gunshot
";
        #endregion
    }
    #region 乐器定义
    public enum MusicNo : uint
    {   /// <summary>
        /// //大钢琴
        /// </summary>
        AcousticGrandPiano = 0,
        /// <summary>
        ///明亮的钢琴
        /// </summary>
        BrightAcousticPiano = 1,
        /// <summary>
        ///电子琴
        /// </summary>
        ElectricGrandPiano = 2,
        /// <summary>
        ///酒吧钢琴
        /// </summary>
        HonkyTonkPiano = 3,
        /// <summary>
        ///柔和钢琴
        /// </summary>
        RhodesPiano = 4,
        /// <summary>
        ///合唱效果钢琴
        /// </summary>
        ChorusedPiano = 5,
        /// <summary>
        ///羽管键琴
        /// </summary>
        Harpsichord = 6,
        /// <summary>
        ///克拉维科特琴
        /// </summary>
        Clavichord = 7,
        /// <summary>
        ///钢片琴
        /// </summary>
        Celesta = 8,
        /// <summary>
        ///钟琴
        /// </summary>
        Glockenspiel = 9,
        /// <summary>
        ///八音盒
        /// </summary>
        Musicbox = 10,
        /// <summary>
        ///颤音琴
        /// </summary>
        Vibraphone = 11,
        /// <summary>
        ///马林巴
        /// </summary>
        Marimba = 12,
        /// <summary>
        ///木琴
        /// </summary>
        Xylophone = 13,
        /// <summary>
        ///管钟
        /// </summary>
        TubularBells = 14,
        /// <summary>
        ///大扬琴
        /// </summary>
        Dulcimer = 15,
        /// <summary>
        /// 击杆风琴
        /// </summary>
        HammondOrgan = 16,
        /// <summary>
        /// 打击式风琴
        /// </summary>
        PercussiveOrgan = 17,
        /// <summary>
        /// 摇滚风琴
        /// </summary>
        RockOrgan = 18,
        /// <summary>
        /// 教堂风琴
        /// </summary>
        ChurchOrgan = 19,
        /// <summary>
        /// 簧管风琴
        /// </summary>
        ReedOrgan = 20,
        /// <summary>
        /// 手风琴
        /// </summary>
        Accordian = 21,
        /// <summary>
        /// 口琴
        /// </summary>
        Harmonica = 22,
        /// <summary>
        ///探戈手风琴
        /// </summary>
        TangoAccordian = 23,
        /// <summary>
        /// 尼龙弦吉他
        /// </summary>
        AcousTicGuitarNylon = 24,
        /// <summary>
        /// 钢弦吉他
        /// </summary>
        AcousTicGuitarSteel = 25,
        /// <summary>
        /// 爵士电吉他
        /// </summary>
        ElectricGuitarJazz = 26,
        /// <summary>
        /// 清音电吉他
        /// </summary>
        ElectricGuitarClean = 27,
        /// <summary>
        /// 闷音电吉他
        /// </summary>
        ElectricGuitarMuted = 28,
        /// <summary>
        /// 加驱动效果的电吉他
        /// </summary>
        OverdrivenGuitar = 29,
        /// <summary>
        /// 加失真效果的电吉他
        /// </summary>
        DistortionGuitar = 30,
        /// <summary>
        /// 吉他和音
        /// </summary>
        GuitarHarmonics = 31,
        /// <summary>
        ///大贝司（声学贝司）
        /// </summary>
        AcousticBass = 32,
        /// <summary>
        /// 电贝司（指弹）
        /// </summary>
        ElectricBassfinger = 33,
        /// <summary>
        /// 电贝司（拨片）
        /// </summary>
        ElectricBassPick = 34,
        /// <summary>
        /// 无品贝司
        /// </summary>
        FretlessBass = 35,
        /// <summary>
        ///  掌击Bass 1
        /// </summary>
        SlapBass1 = 36,
        /// <summary>
        /// 掌击Bass 2
        /// </summary>
        SlapBass2 = 37,
        /// <summary>
        /// 电子合成Bass 1
        /// </summary>
        SynthBass1 = 38,
        /// <summary>
        /// 电子合成Bass 2
        /// </summary>
        SynthBass2 = 39,
        /// <summary>
        ///  小提琴
        /// </summary>
        Violin = 40,
        /// <summary>
        /// 中提琴
        /// </summary>
        Viola = 41,
        /// <summary>
        /// 大提琴
        /// </summary>
        Cello = 42,
        /// <summary>
        /// 低音大提琴
        /// </summary>
        Contrabass = 43,
        /// <summary>
        ///弦乐群颤音音色
        /// </summary>
        TremoloStrings = 44,
        /// <summary>
        ///弦乐群拨弦音色
        /// </summary>
        PizzicatoStrings = 45,
        /// <summary>
        ///竖琴
        /// </summary>
        OrchestralHarp = 46,
        /// <summary>
        ///  定音鼓
        /// </summary>
        Timpani = 47,
        /// <summary>
        ///弦乐合奏音色1
        /// </summary>   
        StringEnsemble1 = 48,
        /// <summary>
        ///弦乐合奏音色2
        /// </summary>
        StringEnsemble2 = 49,
        /// <summary>
        ///合成弦乐合奏音色1
        /// </summary>
        SynthStrings1 = 50,
        /// <summary>
        ///合成弦乐合奏音色2
        /// </summary>
        SynthStrings2 = 51,
        /// <summary>
        ///人声合唱“啊”
        /// </summary>
        ChoirAahs = 52,
        /// <summary>
        ///人声“嘟”
        /// </summary>
        VoiceOohs = 53,
        /// <summary>
        ///合成人声
        /// </summary>
        SynthVoice = 54,
        /// <summary>
        ///管弦敲击齐奏
        /// </summary>
        OrchestraHit = 55,
        /// <summary>
        ///小号
        /// </summary>
        Trumpet = 56,
        /// <summary>
        ///长号
        /// </summary>
        Trombone = 57,
        /// <summary>
        ///大号
        /// </summary>
        Tuba = 58,
        /// <summary>
        ///加弱音器小号
        /// </summary>
        MutedTrumpet = 59,
        /// <summary>
        ///法国号（圆号）
        /// </summary>
        FrenchHorn = 60,
        /// <summary>
        ///铜管组（铜管乐器合奏音色）
        /// </summary>
        BrassSection = 61,
        /// <summary>
        ///合成铜管音色1
        /// </summary>
        SynthBrass1 = 62,
        /// <summary>
        ///合成铜管音色2
        /// </summary>
        SynthBrass2 = 63,
        /// <summary>
        ///高音萨克斯风
        /// </summary>
        SopranoSax = 64,
        /// <summary>
        ///次中音萨克斯风
        /// </summary>
        AltoSax = 65,
        /// <summary>
        ///中音萨克斯风
        /// </summary>
        TenorSax = 66,
        /// <summary>
        ///低音萨克斯风
        /// </summary>
        BaritoneSax = 67,
        /// <summary>
        ///双簧管
        /// </summary>
        Oboe = 68,
        /// <summary>
        ///英国管
        /// </summary>
        EnglishHorn = 69,
        /// <summary>
        ///巴松（大管）
        /// </summary>
        Bassoon = 70,
        /// <summary>
        ///单簧管（黑管）
        /// </summary>
        Clarinet = 71,
        /// <summary>
        ///短笛
        /// </summary>
        Piccolo = 72,
        /// <summary>
        ///长笛
        /// </summary>
        Flute = 73,
        /// <summary>
        ///竖笛
        /// </summary>
        Recorder = 74,
        /// <summary>
        ///排箫
        /// </summary>
        PanFlute = 75,
        /// <summary>
        ///[吹瓶口]
        /// </summary>
        BottleBlow = 76,
        /// <summary>
        ///日本尺八
        /// </summary>
        Shakuhachi = 77,
        /// <summary>
        ///口哨声
        /// </summary>
        Whistle = 78,
        /// <summary>
        ///奥卡雷那
        /// </summary>
        Ocarina = 79,
        /// <summary>
        ///合成主音1（方波）
        /// </summary>           
        Lead1Square = 80,
        /// <summary>
        ///合成主音2（锯齿波）
        /// </summary>
        Lead2Sawtooth = 81,
        /// <summary>
        ///合成主音3
        /// </summary>
        Lead3CaliopeLead = 82,
        /// <summary>
        ///合成主音4
        /// </summary>
        Lead4ChiffLead = 83,
        /// <summary>
        ///合成主音5
        /// </summary>
        Lead5Charang = 84,
        /// <summary>
        ///合成主音6（人声）
        /// </summary>
        Lead6Voice = 85,
        /// <summary>
        ///合成主音7（平行五度）
        /// </summary>
        Lead7Fifths = 86,
        /// <summary>
        ///合成主音8（贝司加主音）
        /// </summary>
        Lead8BassLead = 87,
        /// <summary>
        ///合成音色1（新世纪）
        /// </summary>
        Pad1NewAge = 88,
        /// <summary>
        ///合成音色2 （温暖）
        /// </summary>
        Pad2Warm = 89,
        /// <summary>
        ///合成音色3
        /// </summary>
        Pad3Polysynth = 90,
        /// <summary>
        ///合成音色4 （合唱）
        /// </summary>
        Pad4Choir = 91,
        /// <summary>
        ///合成音色5
        /// </summary>
        Pad5Bowed = 92,
        /// <summary>
        ///合成音色6 （金属声）
        /// </summary>
        Pad6Metallic = 93,
        /// <summary>
        ///合成音色7 （光环）
        /// </summary>
        Pad7Halo = 94,
        /// <summary>
        ///合成音色8
        /// </summary>
        Pad8Wweep = 5,
        /// <summary>
        ///合成效果 1 雨声
        /// </summary>
        
        FX1Rain = 96,
        /// <summary>
        ///合成效果 2 音轨
        /// </summary>
        FX2Soundtrack = 97,
        /// <summary>
        ///合成效果 3 水晶
        /// </summary>
        FX3Crystal = 98,
        /// <summary>
        ///合成效果 4 大气
        /// </summary>
        FX4Atmosphere = 99,
        /// <summary>
        ///合成效果 5 明亮
        /// </summary>
        FX5Brightness = 100,
        /// <summary>
        ///合成效果 6 鬼怪
        /// </summary>
        FX6Goblins = 101,
        /// <summary>
        ///合成效果 7 回声
        /// </summary>
        FX7Echoes = 102,
        /// <summary>
        ///合成效果 8 科幻
        /// </summary>
        FX8Scifi = 103,
        /// <summary>
        ///西塔尔（印度）
        /// </summary>
        Sitar = 104,
        /// <summary>
        ///班卓琴（美洲）
        /// </summary>
        Banjo = 105,
        /// <summary>
        ///三昧线（日本）
        /// </summary>
        Shamisen = 106,
        /// <summary>
        ///十三弦筝（日本）
        /// </summary>
        Koto = 107,
        /// <summary>
        ///卡林巴
        /// </summary>
        Kalimba = 108,
        /// <summary>
        ///风笛
        /// </summary>
        Bagpipe = 109,
        /// <summary>
        ///民族提琴
        /// </summary>
        Fiddle = 110,
        /// <summary>
        ///山奈
        /// </summary>
        Shanai = 111,
        /// <summary>
        /// 叮当铃
        /// </summary>
        TinkleBell = 112,
        /// <summary>
        ///[中文名称暂缺]
        /// </summary>
        Agogo = 113,
        /// <summary>
        ///钢鼓
        /// </summary>
        SteelDrums = 114,
        /// <summary>
        ///木鱼
        /// </summary>
        Woodblock = 115,
        /// <summary>
        ///太鼓
        /// </summary>
        TaikoDrum = 116,
        /// <summary>
        ///通通鼓
        /// </summary>
        MelodicTom = 117,
        /// <summary>
        ///合成鼓
        /// </summary>
        SynthDrum = 118,
        /// <summary>
        ///铜钹
        /// </summary>
        ReverseCymbal = 119,
        /// <summary>
        ///吉他换把杂音
        /// </summary>
        GuitarFretNoise = 120,
        /// <summary>
        ///呼吸声
        /// </summary>
        BreathNoise = 121,
        /// <summary>
        ///海浪声
        /// </summary>
        Seashore = 122,
        /// <summary>
        ///鸟鸣
        /// </summary>
        BirdTweet = 123,
        /// <summary>
        ///电话铃
        /// </summary>
        TelephoneRing = 124,
        /// <summary>
        ///直升机
        /// </summary>
        Helicopter = 125,
        /// <summary>
        ///鼓掌
        /// </summary>
        Applause = 126,
        /// <summary>
        /// Gunshot
        /// </summary>
        Gunshot = 127,
    }
    public enum OpenFlag : uint
    {
        CALLBACK_NULL = 0x00000000,//{当 dwCallback 是 nil 时指定}
        CALLBACK_WINDOW = 0x00010000,//{当 dwCallback 是窗口句柄时指定}
        CALLBACK_FUNCTION = 0x0003000,// {当 dwCallback 是函数指针时指定}
    }
    public enum OpenMsg : uint
    {
        MMSYSERR_BADDEVICEID = 2,//{设备ID超界}
        MMSYSERR_ALLOCATED = 4, //{指定的资源已被分配}
        MMSYSERR_NOMEM = 7, //{不能分配或锁定内存}
        MIDIERR_NOMAP = 66,//{当前没有 MIDI 映射, 只有打开映射程序才可能发生}
        MIDIERR_NODEVICE = 68,//{MIDI 映射中的端口不存在, 只有打开映射程序才可能发生}
    }
    #endregion
    public class MIDIHelper
    {
        #region API
        [DllImport("winmm.dll")]
        static extern uint midiOutOpen(out IntPtr lphMidiOut, uint uDeviceID, IntPtr dwCallback, IntPtr dwInstance, uint dwFlags);//打开数字乐器接口输出
        [DllImport("winmm.dll")]
        static extern uint midiOutClose(IntPtr hMidiOut);//关闭数字乐器接口输出
        [DllImport("winmm.dll")]
        static extern uint midiOutShortMsg(IntPtr hMidiOut, uint dwMsg);//发送数字乐器接口消息

        #endregion
        #region 自定义变量
        IntPtr DeviceHandle = IntPtr.Zero;
        public bool Opend { get; private set; } = false;

        #endregion
        #region 方法
        public void Open()
        {
            IntPtr device;//此处后续要用
            uint hand = midiOutOpen(out device, 0, IntPtr.Zero, IntPtr.Zero, 0);
            Opend = hand == 0;
            DeviceHandle = device;
            Console.WriteLine("已打开MIDI设备");
        }
        /// <summary>
        /// 播放声音返回0表示成功！621表示设备未打开
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>

        public uint Play(uint msg, int time)//播放，尝试了很多写法，发现msg * 256 + 0x00403B90;基本正常，百度百科的方法声音沙哑（msg*256+144+volume*655536+channel）
        {
            if (Opend && DeviceHandle != IntPtr.Zero)
            {
                uint data = msg * 256 + 0x00403B90;
                //Console.WriteLine(data);
                uint ms = midiOutShortMsg(DeviceHandle, data);
                System.Threading.Thread.Sleep(time);
                return msg;
            }
            else
                return 621;
        }
        public uint Play(uint msg)
        {
            if (Opend && DeviceHandle != IntPtr.Zero)
            {
                uint data = msg * 256 + 0x00403B90;
                //Console.WriteLine(data);
                uint ms = midiOutShortMsg(DeviceHandle, data);
                return msg;
            }
            else
                return 621;
        }
        public uint Play(uint msg, uint volume, uint channel)
        {
            //msg=&H90 + ((flip) * &H100) + (volume * &H10000) + channel
            //&H 16进制
            //flip是Integer型参数，代表音的高低，相邻为半音，如60和61，隔1为全音，如63和65
            //volume为设备的音量值，普遍使用的是0-100之间的值
            //channel为通道，默认使用0即可  
            //所谓通道就是MIDI音乐中的音层，就像电子琴的16个音层，有节奏通道，和弦通道，
            //低音通道等等。最大可以支持16层，可以取其任意一个值即可
            //注意：使用完此命令后马上调用midioutclose关闭设备。
            if (Opend && DeviceHandle != IntPtr.Zero)
            {
                uint data = 0x90 + msg * 0x100 + volume * 0x10000 + channel;
                //Console.WriteLine(data);
                uint ms = midiOutShortMsg(DeviceHandle, data);
                return msg;
            }
            else
            {
                return 621;
            }
        }
        public uint Stop(uint msg, uint channel)
        {
            uint data = 0x100 * msg + 0x80 + channel;
            var r_u= midiOutShortMsg(DeviceHandle, data);
            //Console.WriteLine(r_u);
            return r_u;

        }
        /// <summary>
        /// 改变乐器
        /// </summary>
        /// <param name="musicNo"></param>
        /// <returns></returns>
        public uint ChangeInstruments(MusicNo musicNo)//改变乐器
        {
            Console.WriteLine("改变乐器为" + musicNo);
            return midiOutShortMsg(DeviceHandle, Convert.ToUInt32(192 + (uint)musicNo * 256));
        }
        public void Close()//关闭设备
        {
            uint msg = midiOutClose(DeviceHandle);
            Console.WriteLine("已关闭MIDI设备");
        }
        #endregion
    }
}
